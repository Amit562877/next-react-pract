export function addToCart(item) {
    try {
        const storeItem = localStorage.getItem('cartItems');
        const items = storeItem ? JSON.parse(storeItem) : [];
        localStorage.setItem('cartItems', JSON.stringify([...items, { ...item, quantity: 1 }]));
        return [...items, { ...item, quantity: 1 }];
    } catch (e) {
        return [];
    }
}
export function addQuantity(id) {
    try {
        const storeItem = localStorage.getItem('cartItems');
        const items = storeItem ? JSON.parse(storeItem) : [];
        const itemIndex = items.findIndex((obj => obj.id == id));
        items[itemIndex].quantity = items[itemIndex].quantity + 1;
        localStorage.setItem('cartItems', JSON.stringify(items));
        return items;
    } catch (e) {
        return [];
    }
}
export function removeQuantity(id) {
    try {
        const storeItem = localStorage.getItem('cartItems');
        const items = storeItem ? JSON.parse(storeItem) : [];
        const itemIndex = items.findIndex((obj => obj.id == id));
        if (items[itemIndex].quantity > 1) {
            items[itemIndex].quantity = items[itemIndex].quantity - 1;
            localStorage.setItem('cartItems', JSON.stringify(items));
        }
        return items;
    } catch (e) {
        return [];
    }
}
export function removeItemFromCart(id) {
    try {
        const storeItem = localStorage.getItem('cartItems');
        const items = (storeItem ? JSON.parse(storeItem) : []).filter(el => el.id != id);
        localStorage.setItem('cartItems', JSON.stringify(items));
        return items;
    } catch (e) {
        return [];
    }
}
export function getALlCartItems() {
    try {
        const storeItem = localStorage.getItem('cartItems');
        return storeItem ? JSON.parse(storeItem) : [];
    } catch (e) {
        return [];
    }
}
export function checkItemInCart(id) {
    try {
        const storeItem = localStorage.getItem('cartItems');
        const items = storeItem ? JSON.parse(storeItem) : [];
        return items.some(el => el.id == id)
    } catch (e) {
        return [];
    }
}