import { ProducList } from "./fakeApi";

export function getProducts() {
    return ProducList;
}