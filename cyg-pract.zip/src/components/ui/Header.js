import { Button } from "@mui/material";
import DarkModeIcon from '@mui/icons-material/DarkMode';
import DarkModeOutlinedIcon from '@mui/icons-material/DarkModeOutlined';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import styles from "/styles/Home.module.css";
import { useEffect, useState } from "react";
import Link from "next/link";
import HomeIcon from '@mui/icons-material/Home';
import { useSelector } from "react-redux";
import PropTypes from 'prop-types';

function Header(props) {
  const [count, setItemCount] = useState(0);
  const sessionData = useSelector((state) => state.sessionData);
  const { cartItems } = sessionData;
  const { changeTheme, theme } = props;

  useEffect(() => {
    setItemCount(cartItems.length);
  }, [cartItems])

  return (

    <header className={styles.header}>
      <Link href={"/"}><Button variant='outlined'><HomeIcon /></Button></Link>
      {theme == 'dark' && <Button onClick={changeTheme} variant='outlined'><DarkModeIcon /></Button>}
      {theme == 'light' && <Button onClick={changeTheme} variant='outlined'><DarkModeOutlinedIcon /></Button>}
      <Link href={"/cart-details"}><Button variant='outlined'><ShoppingCartIcon />{count}</Button></Link>
    </header>
  );
}

export default Header;
Header.propTypes = {
  changeTheme: PropTypes.func.isRequired,
  theme: PropTypes.string.isRequired
}
