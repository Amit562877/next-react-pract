import * as React from 'react';
import Button from '@mui/material/Button';
import PropTypes from 'prop-types';

export default function PrimaryButton(props) {
    return (
        <Button color={props.color} variant={props.variant} sx={props.sx} onClick={props.onClick}>{props.icon}{props.text}</Button>
    );
}

PrimaryButton.propTypes = {
    variant: PropTypes.string.isRequired,
    text: PropTypes.string.isRequired,
    icon: PropTypes.any,
    sx: PropTypes.object,
    color: PropTypes.string.isRequired,
    onClick: PropTypes.func.isRequired,
}