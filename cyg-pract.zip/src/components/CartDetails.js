import { Grid } from "@mui/material";
import CartItem from "./CartItem";
import EmptyCart from "./EmptyCart";
import PropTypes from 'prop-types';
import { useDispatch } from "react-redux";
import { addQuantityToCart, removeItem, removeQuantityFromCart } from "../../store/actions/sessionAction";

function CartDetails({ cartItems }) {
    const dispatch = useDispatch();

    const onItemRemove = (id) => {
        dispatch(removeItem(id));
    }
    const onQuantityAdd = (id) => {
        dispatch(addQuantityToCart(id));
    }
    const onQuantityRemove = (id) => {
        dispatch(removeQuantityFromCart(id));
    }
    return (
        <Grid container spacing={4}
            direction="row"
            justifyContent="space-evenly"
            alignItems="center"
            style={{
                display: 'flex', minHeight: '100vh',
                alignItems: 'unset'
            }} columns={{ xs: 4, md: 12 }}>
            {
                cartItems.length > 0 && cartItems.map((item) => {
                    return <CartItem key={item.id} item={item} onItemRemove={onItemRemove} onQuantityAdd={onQuantityAdd} onQuantityRemove={onQuantityRemove}></CartItem>
                })
            }
            {cartItems.length == 0 && <EmptyCart></EmptyCart>}
        </Grid >
    );
}

export default CartDetails;

CartDetails.propTypes = {
    cartItems: PropTypes.array.isRequired,
}
