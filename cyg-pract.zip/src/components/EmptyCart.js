import { useState } from "react";
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { Button, Grid } from '@mui/material';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import Link from "next/link";
export default function EmptyCart(props) {
    return (
        <Grid item xs={12} md={12} sm={12}>
            <Card sx={{
                height: '100vh',
                alignItems: 'center',
                justifyContent: 'center',
                display: 'flex'
            }}>
                <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                        Cart is empty!
                    </Typography>
                    <Link href={"/"}><Button variant='outlined'><ShoppingCartIcon />Back to shopping</Button></Link>
                </CardContent>
            </Card>
        </Grid>
    );
}
