import { Grid } from "@mui/material";
import ProductItem from "./ProductItem";
import PropTypes from 'prop-types';

function Products({ items }) {
    
    return (
        <Grid container spacing={4}
            direction="row"
            justifyContent="space-evenly"
            columns={{ xs: 4, md: 12 }}>
            {items.map((item) => {
                return <ProductItem key={item.id} item={item}></ProductItem>
            })}
        </Grid>
    );
}

export default Products;

Products.propTypes = {
    itema: PropTypes.array.isRequired,
}