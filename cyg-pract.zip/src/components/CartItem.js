import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { Button, Grid } from '@mui/material';
import RemoveShoppingCartIcon from '@mui/icons-material/RemoveShoppingCart';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import { Box } from "@mui/system";
import PrimaryButton from "./ui/PrimaryButton";
import PropTypes from 'prop-types';

export default function CartItem(props) {
    const { item, onItemRemove, onQuantityRemove, onQuantityAdd } = props;

    return (
        <Grid item xs={12}>
            <Card sx={{ display: 'flex' }}>
                <div>
                    <CardMedia
                        component="img"
                        image={item.image}
                        alt={item.title}
                        sx={{ width: '200px', borderRadius: '10px' }}
                    />
                </div>
                <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                    <CardContent>
                        <Typography gutterBottom variant="h5" component="div">
                            {item.title} ({item.category})
                        </Typography>
                        <Typography gutterBottom variant="h5" component="div">
                            ${item.price}
                        </Typography>
                        <Typography gutterBottom variant="h5" component="div">
                            <Button onClick={(e) => { onQuantityRemove(item.id) }} variant='outline' disabled={item.quantity == 1}><RemoveIcon /></Button>{item.quantity}<Button onClick={(e) => { onQuantityAdd(item.id) }} variant='outline'><AddIcon /></Button>
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            {item.description}
                        </Typography>
                    </CardContent>
                    <Box sx={{ display: 'flex', alignItems: 'center', pl: 1, pb: 1 }}>
                        <PrimaryButton onClick={(e) => { onItemRemove(item.id) }} variant='contained' color={'secondary'} text={'Remove Item'} icon={<RemoveShoppingCartIcon />}></PrimaryButton>
                    </Box>
                </Box>
            </Card >
        </Grid >
    );
}

CartItem.propTypes = {
    item: PropTypes.object.isRequired,
    onItemRemove: PropTypes.func.isRequired,
    onQuantityRemove: PropTypes.func.isRequired,
    onQuantityAdd: PropTypes.func.isRequired
}