import { useState } from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActions, Grid } from '@mui/material';
import { checkItemInCart } from '../services/sessionService';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import RemoveShoppingCartIcon from '@mui/icons-material/RemoveShoppingCart';
import PrimaryButton from './ui/PrimaryButton';
import PropTypes from 'prop-types';
import { useDispatch } from "react-redux";
import { addItem, removeItem } from '../../store/actions/sessionAction';

export default function ProductItem({ item }) {
    const dispatch = useDispatch();
    const [isItemIntoCart, setIsItemIntoCart] = useState(checkItemInCart(item.id));
    const onAddToCart = () => {
        if (isItemIntoCart) {
            dispatch(removeItem(item.id));
            setIsItemIntoCart(false);
        } else {
            dispatch(addItem(item));
            setIsItemIntoCart(true);
        }
    }
    return (
        <Grid item xs={3} md={3} sm={12}>
            <Card sx={{ height: '100%', maxHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
                <div>
                    <CardMedia
                        component="img"
                        height="140"
                        image={item.image}
                        alt={item.title}
                    />
                </div>
                <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                        {item.title} ({item.category})
                    </Typography>
                    <Typography gutterBottom variant="h5" component="div">
                        ${item.price}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        {item.description}
                    </Typography>

                </CardContent>
                <CardActions sx={{ marginTop: 'auto' }}>
                    {isItemIntoCart && <PrimaryButton sx={{
                        margin: 'auto'
                    }} onClick={onAddToCart} variant='contained' color={'secondary'} text={'Remove Item'} icon={<RemoveShoppingCartIcon />}></PrimaryButton>
                    }
                    {!isItemIntoCart && <PrimaryButton sx={{
                        margin: 'auto'
                    }} onClick={onAddToCart} variant='contained' color={'primary'} text={'Add To Cart'} icon={<AddShoppingCartIcon />}></PrimaryButton>
                    }
                </CardActions>
            </Card>
        </Grid>
    );
}

ProductItem.propTypes = {
    item: PropTypes.object.isRequired,
}