import { getALlCartItems } from "../../src/services/sessionService";
import { UPDATE_CART, UPDATE_CART_ERROR } from "../types";

const initialState = {
  cartItems: getALlCartItems(),
  loading: true,
  error: null
};

const sessionReducer = (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_CART:
      return {
        ...state,
        cartItems: action.payload,
        loading: false,
      };

    case UPDATE_CART_ERROR:
      return {
        loading: false,
        error: action.payload,
      };

    default:
      return state;
  }
};

export default sessionReducer;
