import { combineReducers } from "redux";
import productReducer from "./productReducer";
import sessionReducer from "./sessionReducer";

export default combineReducers({
  productData: productReducer,
  sessionData: sessionReducer
});
