import { addQuantity, addToCart, removeItemFromCart, removeQuantity } from "../../src/services/sessionService";
import { UPDATE_CART } from "../types";

export const addQuantityToCart = (id) => async (dispatch) => {
  try {
    const items = addQuantity(id);
    dispatch({
      type: UPDATE_CART,
      payload: items,
    });
  } catch (error) {
    dispatch({
      type: UPDATE_CART_ERROR,
      payload: "error in cart update",
    });
  }
};
export const removeQuantityFromCart = (id) => async (dispatch) => {
  try {
    const items = removeQuantity(id);
    dispatch({
      type: UPDATE_CART,
      payload: items,
    });
  } catch (error) {
    dispatch({
      type: UPDATE_CART_ERROR,
      payload: "error in cart update",
    });
  }
};

export const removeItem = (id) => async (dispatch) => {
  try {
    const items = removeItemFromCart(id);
    dispatch({
      type: UPDATE_CART,
      payload: items,
    });
  } catch (error) {
    dispatch({
      type: UPDATE_CART_ERROR,
      payload: "error in cart update",
    });
  }
};

export const addItem = (item) => async (dispatch) => {
  try {
    const items = addToCart(item);
    dispatch({
      type: UPDATE_CART,
      payload: items,
    });
  } catch (error) {
    dispatch({
      type: UPDATE_CART_ERROR,
      payload: "error in cart update",
    });
  }
};
