import { getProducts } from "../../src/services/mocks/productApi";
import { GET_PRODUCTS, PRODUCTS_ERROR } from "../types";

export const getProductData = () => async (dispatch) => {
  try {
    dispatch({
      type: GET_PRODUCTS,
      payload: getProducts(),
    });
  } catch (error) {
    dispatch({
      type: PRODUCTS_ERROR,
      payload: "error to get product",
    });
  }
};
