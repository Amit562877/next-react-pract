import Head from 'next/head'
import styles from '../styles/Home.module.css'
import Products from '../src/components/Products';
import { useEffect } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { getProductData } from '../store/actions/productAction';

export default function ProducList() {
  const dispatch = useDispatch();
  const productListData = useSelector((state) => state.productData);
  const { products } = productListData;
  useEffect(() => {
    dispatch(getProductData());
  }, [dispatch]);
  return (
    <div className={styles.container}>
      <Head>
        <title>Product List</title>
        <meta name="description" content="List of all the available producst" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Products items={products}></Products>
    </div>
  )
}
