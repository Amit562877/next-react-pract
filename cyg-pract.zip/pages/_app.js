import '../styles/globals.css'
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { useEffect, useState } from 'react';
import Header from '../src/components/ui/Header';
import Footer from '../src/components/ui/Footer';
import { wrapper, store } from "../store/store";
import { Provider } from "react-redux";

function MyApp({ Component, pageProps }) {
  const [theme, setTheme] = useState('dark');
  let Theme = createTheme({
    palette: {
      mode: theme,
    },
  });
  const [hasWindow, setHasWindow] = useState(false);
  useEffect(() => {
    if (typeof window !== "undefined") {
      setHasWindow(true);
    }
  }, []);
  const changeTheme = () => {
    setTheme((theme == 'dark' ? 'light' : 'dark'));
    Theme = createTheme({
      palette: {
        mode: theme,
      },
    });
  }
  return <Provider store={store}>
    <ThemeProvider theme={Theme}>
      <CssBaseline />
      {hasWindow && <><Header changeTheme={changeTheme} theme={theme} />
        <Component {...pageProps} />
        <Footer /></>}
    </ThemeProvider>
  </Provider>
}

export default wrapper.withRedux(MyApp)
