import Head from 'next/head'
import styles from '../styles/Home.module.css'
import CartDetails from '../src/components/CartDetails';
import { useSelector } from "react-redux";

export default function ProducList() {
  const sessionData = useSelector((state) => state.sessionData);
  let { cartItems } = sessionData;

  return (
    <div className={styles.container}>
      <Head>
        <title>Cart Detail</title>
        <meta name="description" content="List of all the available producst" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <CartDetails cartItems={cartItems}></CartDetails>
    </div>
  )
}

